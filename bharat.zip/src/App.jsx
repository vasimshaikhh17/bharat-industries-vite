import React from 'react'
import css from './styles/App.module.scss'
import Home from './components/pages/Home'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import About from './components/pages/About'
import Ourproducts from './components/pages/Ourproduct'
import Industries from './components/pages/Industries'
import Contactus from './components/pages/Contactus'
import Sheetmetalpart from './components/pages/Sheetmetalpart'
import Sheetmetaltool from './components/pages/Sheetmeataltools'
import Switchgear from './components/pages/Switchgear'
import Metalstamping from './components/pages/Metalstamping'
import Materialsformetalstamping from './components/pages/Materialsformetalstamping'
import Stampedmetal from './components/pages/Stampedmetal'
import Header2 from './components/common/Header/Header2'

const App = () => {
  //don't forget to add font link in index.html
  return (
    <div className={`bg-primary ${css.container}`}>
      {/* <Header2/> */}
      <BrowserRouter>
        <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/about' element={<About/>}/>
        <Route path='/Ourproducts' element={<Ourproducts/>}/>
        <Route path='/industries' element={<Industries/>}/>
        <Route path='/contactus' element={<Contactus/>}/>
        <Route path='/Sheetmetalpart' element={<Sheetmetalpart/>}/>
        <Route path='/Sheetmetaltool' element={<Sheetmetaltool/>}/>
        <Route path='/Switchgear' element={<Switchgear/>}/>
        <Route path='/Metalstamping' element={<Metalstamping/>}/>
        <Route path='/Materialsformetalstamping' element={<Materialsformetalstamping/>}/>
        <Route path='/Stampedmetal' element={<Stampedmetal/>}/>
        </Routes>
      </BrowserRouter>
    </div>
  )
}

export default App