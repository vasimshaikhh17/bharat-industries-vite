import React from "react";
import { footerVariants, staggerChildren } from "../../../utils/motion";

import css from "./Footer.module.scss";
import { motion } from "framer-motion";
import footerlogo from '../../../assets/new.images/logo.png'

const Footer = () => {
  return (
    <motion.section
      variants={staggerChildren}
      initial="hidden"
      whileInView="show"
      viewport={{ once: false, amount: 0.25 }}
      className={`paddings ${css.wrapper}`}
    >
      <motion.div
        variants={footerVariants}
        className={`innerWidth yPaddings flexCenter ${css.container}`}
      >
        {/* <div className={css.left}>
          <span className="primaryText">
            Just call at +001 (313) 345 678<br />
            to make a quotation. <br />
            
            <span style={{textAlign:"center"}}>or</span>
       </span>
          <span className="primaryText">
            	&#8594; <a href="mailto:zainkeepscode@gmail.com">Email me</a>
          </span>
        </div> */}

        {/* previously held footer part */}

        {/* <div className={css.right}>
          <div className={css.info}>
            <span className="secondaryText">Information</span>
            <p>145 New York, FL 5467, USA</p>
          </div>
          <ul className={css.menu}>
            <li>Services</li>
            <li>Works</li>
            <li>Notes</li>
            <li>Experience</li>
          </ul>
        </div> */}

        <footer id="footer">
          <div className="footer-content">
            <div className="container">
              <div className="row">
                <div className="col-lg-3 lblcenter">
                  <div className="widget">
                    <div className="widget-title">
                      <img
                        loading="lazy"
                        src={footerlogo}
                        alt="Bharat Industries"
                        style={{height:'4rem', paddingBottom:'1rem'}}
                      />
                    </div>
                    <p
                      className="mb-5"
                      style={{ padding: "0.5rem 0rem", lineHeight: "2" }}
                    >
                      We, Bharat Industries, began its operations in the year
                      2000, as manufacturer and supplier of a wide range of
                      precision pressed sheet metal parts and components...
                      <a
                        href="about-us.html"
                        style={{ textDecoration: "none", color: "#000" }}
                      >
                        <b>Read More</b>
                      </a>
                    </p>
                  </div>
                </div>
                <div className="col-lg-9 lblcenter">
                  <div className="row">
                    <div className="col-lg-3">
                      <div className="widget">
                        <div className="widget-title">Quick Links </div>
                        <ul
                          className="list"
                          style={{
                            listStyle: "none",
                            padding: "0.5rem 0rem",
                            lineHeight: "2",
                          }}
                        >
                          <li>
                            <a
                              href="/"
                              style={{ textDecoration: "none", color: "#000" }}
                            >
                              Home
                            </a>
                          </li>
                          <li>
                            <a
                              href="/about"
                              style={{ textDecoration: "none", color: "#000" }}
                            >
                              About Us{" "}
                            </a>
                          </li>
                          <li>
                            <a
                              href="/Ourproducts"
                              style={{ textDecoration: "none", color: "#000" }}
                            >
                              Our Product
                            </a>
                          </li>
                          <li>
                            <a
                              href="/industries"
                              style={{ textDecoration: "none", color: "#000" }}
                            >
                              Industries
                            </a>
                          </li>
                          <li>
                            <a
                              href="/contactus"
                              style={{ textDecoration: "none", color: "#000" }}
                            >
                              Contact Us{" "}
                            </a>
                          </li>
                        </ul>
                      </div>
                    </div>
                    <div className="col-lg-4">
                      <div className="widget">
                        <div className="widget-title">Our Products</div>
                        <ul
                          className="list"
                          style={{
                            listStyle: "none",
                            padding: "0.5rem 0rem",
                            lineHeight: "2",
                          }}
                        >
                          <li>
                            <a
                              href="/Ourproducts"
                              style={{ textDecoration: "none", color: "#000" }}
                            >
                              Sheet Metal Parts
                            </a>
                          </li>
                          <li>
                            <a
                              href="/Ourproducts"
                              style={{ textDecoration: "none", color: "#000" }}
                            >
                              Sheet Metal Tools
                            </a>
                          </li>
                          <li>
                            <a
                              href="/Ourproducts"
                              style={{ textDecoration: "none", color: "#000" }}
                            >
                              Switchgear Components &amp; Parts
                            </a>
                          </li>
                          <li>
                            <a
                              href="/Ourproducts"
                              style={{ textDecoration: "none", color: "#000" }}
                            >
                              Metal Stamping
                            </a>
                          </li>
                          <li>
                            <a
                              href="/Ourproducts"
                              style={{ textDecoration: "none", color: "#000" }}
                            >
                              Materials for Metal Stamping Parts{" "}
                            </a>
                          </li>
                          <li>
                            <a
                              href="/Ourproducts  "
                              style={{ textDecoration: "none", color: "#000" }}
                            >
                              Stamped Metal Parts
                            </a>
                          </li>
                        </ul>
                      </div>
                    </div>
                    <div className="col-lg-5">
                      <div className="widget">
                        <div className="widget-title">Contact Us </div>
                        <ul
                          className="list"
                          style={{
                            listStyle: "none",
                            padding: "0.5rem 0rem",
                            lineHeight: "2",
                          }}
                        >
                          <li style={{ display: "flex" }}>
                            <i className="fa fa-building" />
                            <p> Bharat Industries</p>
                          </li>
                          <li style={{ display: "flex" }}>
                            <i className="fa fa-map-marker-alt" />
                            <p>
                              26, Bhagirath Estate Part 2, Old Swastik Mill
                              Store Compound, opp. Jawahar Nagar, Amraiwadi,{" "}
                              <a
                                href="/contactus"
                                style={{ textDecoration: "none" }}
                              >
                                <b>Ahmedabad</b>
                              </a>
                              , Gujarat, India - 380026
                            </p>
                          </li>
                          <li style={{ display: "flex" }}>
                            <i className="fa fa-envelope" />
                            <p>
                              <a
                                href="mailto:Khyatiinds@gmail.com"
                                style={{ textDecoration: "none" }}
                              >
                                bharatinds@gmail.com
                              </a>
                            </p>
                          </li>
                          <li style={{ display: "flex" }}>
                            <i className="fa fa-mobile" />
                            <p>
                              <a
                                href="tel:+91 9925043020"
                                style={{ textDecoration: "none" }}
                              >
                                +91 9925043020
                              </a>
                            </p>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="copyright-content">
            <div className="container">
              <div className="copyright-text text-center">
                <p className="text-custom-white no-margin text-black">
                  Copyrights © 2023 Bharat Industries. Made with{" "}
                  <i
                    className="fa fa-heart"
                    aria-hidden="true"
                    style={{ color: "red !important" }}
                  />{" "}
                  Love and passion by{" "}
                  <a
                    href="http://www.bytefaze.com/"
                    style={{ color: "#ed1b23" }}
                    target="_blank"
                  >
                    ByteFaze Websolutions
                  </a>
                </p>
              </div>
            </div>
          </div>
        </footer>
      </motion.div>
    </motion.section>
  );
};

export default Footer;
