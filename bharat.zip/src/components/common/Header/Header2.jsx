import React, { useEffect, useState } from "react";
import './Header2.css'
import 'bootstrap/dist/css/bootstrap.min.css'
// import logo from '../../assets/img/logo.png'
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { getMenuStyles, headerVariants } from "../../../utils/motion";
import useOutsideAlerter from "../../../hooks/useOutsideAlerter";
import useHeaderShadow from "../../../hooks/useHeaderShadow";
import css from "./Header.module.scss";
import { BiPhoneCall, BiMenuAltRight } from "react-icons/bi";
import logo from "../../../assets/new.images/logo.png"


// import ''

function Header2() {
  const[showSidebar, setShowSidebar] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const headerShadow = useHeaderShadow();


  useEffect(() => {
    const onScroll = () => {
      if (window.scrollY > 40) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    }
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, [])

  function toggleSliderbar() {
    setShowSidebar(!setShowSidebar);
  }
  return (
    <motion.nav
    variants={headerVariants}
    // className={`bg-primary paddings ${css.wrapper}`}
 className={scrolled ? "bgscrolled navbar navbar-expand-lg navbar-dark fixed-top":'bg-transparent navbar navbar-expand-lg navbar-dark'} 
//    style={{background: scrolled ?'#1C1E24':'#b2f2bb'}}>
    style={{boxShadow: headerShadow}}>

  <div className="container">
   {/* <a href="/" title="Back To Home"> <img className="nav-img" src={logo} height={'100px'} width={'100px'}/></a> */}
   <a href="/">
   <img src={logo} className="img-fluid" style={{height:"50px"}}/></a>
    <button className="navbar-toggler shadow-none border-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon" />
    </button>
    <div className="sidebar offcanvas offcanvas-end" tabIndex={-1} id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
      <div className="offcanvas-header text-white border-bottom">
        <h5 className="offcanvas-title" id="offcanvasNavbarLabel" ></h5>
        <button type="button" className="btn-close" data-bs-dismiss="offcanvas" aria-label="Close" />
      </div>
      <div className="offcanvas-body d-flex flex-column flex-lg-row p-4 p-lg-0 align-items-center">
        <ul className="navbar-nav justify-content-center fs-6 flex-grow-1 pe-3 px-3" >
          <li className="nav-item mx-2">
            <a className="nav-link active"  aria-current="page" style={{color: 'black'}} href="/">Home</a>
          </li>
          <li className="nav-item mx-2">
            <a className="nav-link active"  aria-current="page" style={{color: 'black'}} href="/about">About Us</a>
          </li>
          <li className="nav-item mx-2">
            <a className="nav-link active"  aria-current="page" style={{color: 'black'}} href="/ourproducts">Our Product</a>
          </li>
          <li className="nav-item mx-2">
            <a className="nav-link"  style={{color: 'black'}} href="/industries">Industries</a>
          </li>
          <li className="nav-item mx-2">
            <a href='/contactus' className="nav-link"  style={{color: 'black'}}>Contact Us</a>
         </li> 
         {/* <li  className={`flexCenter ${css.phone} nav-item mx-2`} >
            <p style={{marginBottom:'0px'}}>+001 (313) 345 678</p>
            <BiPhoneCall size={"40px"} />
          </li> */}
        </ul>
        <a className="m-tele d-flex flex-column flex-lg-row justify-content-center align-items-center gap-3">
          <a  href="/contactus" className="text-white text-decoration-none px-3 py-1 fs-6" ><i class="bi font-size bi-telephone"></i></a>
          {/* <a href="/contact" className="text-black text-decoration-none px-3 py-1 rounded-4 fs-6">Consultancy</a>   */}
                    <BiPhoneCall size={"40px"} />

        </a>
      </div>
    </div>
  </div>
</motion.nav>

  )
}

export default Header2