import React from 'react'
import Hero from './Homecomponent/Hero/Hero'
import Experties from './Homecomponent/Experties/Experties'
import Work from './Homecomponent/Work/Work'
import Portfolio from './Homecomponent/Portfolio/Portfolio'
import People from './Homecomponent/People/People'
import Layout from '../layout/Layout'

const Home = () => {
  return (
   <>
   <Layout>
      <Hero/>
      <Experties/>
      <Work/>
      <Portfolio/>
      <People/>
 </Layout>
   </>
  )
}

export default Home