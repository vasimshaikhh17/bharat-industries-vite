import React from "react";
import Layout from "../layout/Layout";
import "../pages/About.css";
const Sheetmeataltools = () => {
  return (
    <>

      <Layout>


         {/* image coming from about.css */}
         <section className="hero-about">
          <h1>Switch Gear Components & Parts</h1>
        </section>

   <section>
  <div className="container">
    <div className="row">
      <div className="col-lg-12">
        <div className="row">
          <div className="col-lg-12 descset" style={{marginBottom: 30}}>
            <h2 style={{fontSize: 34, textAlign: 'center'}}>Switchgear Components &amp; Parts Manufacturer</h2>
            <p>Switchgear sheet metal parts refer to the metal components and enclosures used in the construction of switchgear assemblies and panels. These parts are typically fabricated from various types of sheet metal, such as steel or aluminum, and are designed to provide protection, support, and organization for the electrical components and wiring within the switchgear. Here are some common switchgear sheet metal parts:</p>
            <ul>
              <li><b>Enclosures:</b> Switchgear enclosures are protective housings made of sheet metal that house all the internal components of the switchgear, including circuit breakers, busbars, and control panels. These enclosures are designed to provide electrical insulation, environmental protection (e.g., against dust, moisture, and contaminants), and physical security.</li>
              <li><b>Mounting Plates:</b> Mounting plates are flat sheet metal panels installed within the switchgear enclosure. They provide a sturdy surface for attaching various components, such as circuit breakers, busbars, and control panels. Mounting plates are typically pre-drilled or punched with holes to accommodate specific components' mounting requirements.</li>
              <li><b>Busbar Supports:</b> Busbar supports are metal brackets or supports designed to hold and insulate busbars within the switchgear assembly. They help maintain the proper spacing and alignment of busbars and prevent electrical contact with other components.</li>
              <li><b>Covers and Doors:</b> Sheet metal covers and doors are used to close and secure the switchgear enclosure. They provide access to the internal components for maintenance and inspection while protecting against unauthorized access and environmental factors.</li>
              <li><b>Back Panels:</b> Back panels are sheet metal panels installed at the rear of the switchgear enclosure. They provide additional structural support and can serve as a mounting surface for certain components or accessories.</li>
              <li><b>Wireways and Cable Entry Glands:</b> Sheet metal wireways or cable entry glands are used to organize and protect electrical wiring and cables as they enter or exit the switchgear enclosure. These components help prevent damage to cables and ensure a neat and organized wiring layout.</li>
              <li><b>Ventilation Louvers:</b> In some switchgear applications, sheet metal ventilation louvers or vents may be integrated into the enclosure to allow for proper airflow and heat dissipation, especially in applications with high power loads or sensitive electronics.</li>
              <li><b>Internal Mounting Brackets:</b> Internal mounting brackets made of sheet metal are used to secure and support various internal components, such as relays, control devices, and terminal blocks.</li>
              <li><b>Partition Plates:</b> Partition plates are sheet metal dividers installed within the switchgear enclosure to separate different sections or compartments, providing electrical isolation and organization of components.</li>
              <li><b>Grounding Bars and Strips:</b> Grounding bars and strips made of sheet metal provide a connection point for grounding conductors to ensure the safe dissipation of fault currents into the grounding system.</li>
              <li><b>Cable Tray Supports:</b> In larger switchgear assemblies, sheet metal supports may be used to secure cable trays that organize and route cables within the enclosure.</li>
              <li><b>Label Plates:</b> Label plates made of sheet metal can be attached to various components to provide identification and labeling of circuits, devices, and components within the switchgear assembly.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

        </Layout>
    </>
  );
};

export default Sheetmeataltools;
