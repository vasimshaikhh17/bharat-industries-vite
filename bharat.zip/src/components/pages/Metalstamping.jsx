import React from "react";
import Layout from "../layout/Layout";
import "../pages/About.css";
const Metalstamping = () => {
  return (
    <>

      <Layout>


         {/* image coming from about.css */}
         <section className="hero-about">
          <h1>Switch Gear Components & Parts</h1>
        </section>



 <section>
  <div className="container">
    <div className="row">
      <div className="col-lg-12">
        <div className="heading-text heading-section">
          <h2>Metal Stamping</h2>
        </div>
      </div>
      <div className="col-lg-12">
        <div className="row">
          <div className="col-lg-12">
            Our company offers components as per customers drawing specifications all dimension are controlled with perfect dies and tools. Quality is controlled by special inspection gauges, for their critical assembly needs. These components are manufactured by experienced engineers and skilled workers thus providing complete satisfaction to our clients. These sheet metal components are available at most competitive prices.
          </div>
          <div className="col-lg-6">
            <ul className="list-style">
              <li><i className="fa fa-check" />  Progressive Stamping</li>
              <li> <i className="fa fa-check" /> Precision Metal Stamping</li>
              <li> <i className="fa fa-check" /> Custom Metal Stamping</li>
              <li> <i className="fa fa-check" /> Deep Drawn Stamping</li>
              <li> <i className="fa fa-check" /> Fabrication Parts</li>
              <li> <i className="fa fa-check" /> Metal Forming</li>
            </ul>
          </div>
          <div className="col-lg-6">
            <div className="col-lg-6">
              <ul className="list-style">
                <li><i className="fa fa-check" />  Metal Bending</li>
                <li> <i className="fa fa-check" /> Rivestamping</li>
                <li> <i className="fa fa-check" /> Prototype Stamping</li>
                <li> <i className="fa fa-check" /> Sheet Metal Stamping
                </li>
                <li> <i className="fa fa-check" /> Micro Metal Stamping</li>
                <li> <i className="fa fa-check" /> Terminals Stamping</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div></section>

        </Layout>



    </>
  );
};

export default Metalstamping;