// import React from 'react'
// import '../../hooks/functions'

// const Navjs = () => {
//   return (
//     <div>
//          <div id="mainMenu">
//                         <div class="container">
//                             <nav>
//                                 <ul>
//                                     <li><a href="index.html">Home</a></li>
//                                     <li ><a href="about-us.html">About Us</a></li>
//                                     <li class="dropdown"><a href="product.html">Our Product</a>
//                                         <ul class="dropdown-menu">
//                                             <li class="dropdown-submenu dropdown"><a href="sheet-metal-parts.html">Sheet Metal Parts</a>
//                                                 <ul class="dropdown-menu">
//                                                     <li class="dropdown-submenu"><a href="brass-sheet-metal-parts.html">Brass Sheet Metal Parts</a></li>
//                                                     <li class="dropdown-submenu"><a href="ss-sheet-metal-parts.html">S S Sheet Metal Parts</a></li>
//                                                     <li class="dropdown-submenu"><a href="ms-sheet-metal-parts.html">M S Sheet Metal Parts</a></li>
//                                                     <li class="dropdown-submenu"><a href="copper-sheet-metal-parts.html">Copper Sheet Metal Parts</a></li>
//                                                 </ul>
//                                             </li>
//                                             <li class="dropdown-submenu"><a href="sheet-metal-tools.html">Sheet Metal Tools</a></li>
//                                             <li class="dropdown-submenu"><a href="switchgear-components-parts.html">Switchgear Components & Parts</a></li>
//                                             <li class="dropdown-submenu"><a href="metal-stamping.html">Metal Stamping</a></li>
//                                             <li class="dropdown-submenu"><a href="materials-for-metal-stamping-parts.html">Materials for Metal Stamping Parts</a></li>
//                                             <li class="dropdown-submenu"><a href="stamped-metal-parts.html">Stamped Metal Parts</a></li>
//                                         </ul>
//                                     </li>
//                                     <li class="mega-menu-item"><a href="industries.html">Industries</a></li>
//                                     <li class="mega-menu-item"><a href="contact-us.html">Contact Us</a></li>
//                                     <li class="inquiry1">
//                                          <button id="myBtn" class="btn">Quick Inquiry</button>
//                                     </li>
//                                 </ul>
//                             </nav>
//                         </div>
//                     </div>
//     </div>
//   )
// }

// export default Navjs