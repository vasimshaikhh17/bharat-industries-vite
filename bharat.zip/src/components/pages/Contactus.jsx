import React from "react";
import Layout from "../layout/Layout";
import "../pages/About.css";
import cert2 from "../../assets/img/cert-2.jpg";
import cert3 from "../../assets/img/cert-3.jpg";
const Contactus = () => {
  return (
    <>
      <Layout>
        {/* image coming from about.css */}
        <section className="hero-about">
          <h1 style={{color:'White'}}>Contact Us</h1>
        </section>

        <section>
          <div className="container">
            <div className="row" style={{ paddingTop: "2rem" }}>
              <div className="col-lg-6">
                <h3 className="text-uppercase">Get In Touch</h3>
                <p>
                  Thank you for your interest in our company. If you have any
                  questions or concerns about our products, please do not
                  hesitate to contact us. We look forward to hearing from you
                  soon!
                </p>
                <div className="m-t-30">
                  <form method="post" id="form" name="form">
                    <input
                      name="vind"
                      type="hidden"
                      id="vind"
                      defaultValue={53031}
                      ifkey="vind"
                    />
                    <input
                      name="ctype"
                      type="hidden"
                      id="ctype"
                      defaultValue="I1172"
                      ifkey="ctype"
                    />
                    <input
                      name="pname"
                      type="hidden"
                      id="pname"
                      defaultValue="Khyati Industries"
                      ifkey="pname"
                    />
                    <div className="row">
                      <div className="form-group col-md-6">
                        <label htmlFor="name">Name</label>
                        <input
                          type="text"
                          id="name"
                          name="name"
                          className="form-control"
                          placeholder="Name"
                        />
                      </div>
                      <div className="form-group col-md-6">
                        <label htmlFor="email">Email</label>
                        <input
                          type="text"
                          id="mail"
                          className="form-control"
                          name="mail"
                          placeholder="Email"
                        />
                      </div>
                    </div>
                    <div className="row">
                      <div className="form-group col-md-6">
                        <label htmlFor="subject">Your Phone No</label>
                        <input
                          type="text"
                          id="subj"
                          name="subj"
                          placeholder="Phone"
                          className="form-control"
                        />
                      </div>
                      <div className="form-group col-md-6">
                        <label htmlFor="subject">Your Location</label>
                        <input
                          type="text"
                          id="location"
                          name="location"
                          placeholder="Location"
                          className="form-control"
                        />
                      </div>
                    </div>
                    <div className="form-group">
                      <label htmlFor="message">Message</label>
                      <textarea
                        id="message"
                        name="message"
                        className="form-control"
                        placeholder="Enter Your Message"
                        defaultValue={""}
                      />
                    </div>
                    <button
                      style={{
                        backgroundColor: "#02B0F3",
                        padding: "10px 20px",
                        borderRadius: "2rem",
                        marginTop: "2rem",
                      }}
                      type="button"
                      name="submit"
                      onclick="PostData(this.form)"
                      className="btn"
                    >
                      SEND MESSAGE
                    </button>
                  </form>
                </div>
              </div>
              <div className="col-lg-6">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14689.414718028105!2d72.6249257!3d23.0107827!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e877e7df16e53%3A0x76094bd392c9d3d7!2sKhyati%20Industries!5e0!3m2!1sen!2sin!4v1680867610327!5m2!1sen!2sin"
                  width="100%"
                  height={450}
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>
          </div>
        </section>
      </Layout>
    </>
  );
};

export default Contactus;
