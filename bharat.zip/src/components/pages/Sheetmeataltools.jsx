import React from "react";
import Layout from "../layout/Layout";
import "../pages/About.css";
const Sheetmeataltools = () => {
  return (
    <>

      <Layout>


         {/* image coming from about.css */}
         <section className="hero-about">
          <h1>Sheet Metal Parts</h1>
        </section>



 
  <section>
    <div className="container">
      <div className="row">
        <div className="col-lg-12">
          <div className="row">
            <div className="col-lg-12 descset" style={{marginBottom: 30}}>
              <h2 style={{fontSize: 34, textAlign: 'center'}}>Sheet Metal Tools Manufacturer</h2>
              <p>Sheet metal tools are specialized tools used for cutting, shaping, and manipulating sheet metal, which is a thin and flat piece of metal often used in various industries for construction, manufacturing, automotive, and HVAC (Heating, Ventilation, and Air Conditioning) applications. These tools are essential for fabricating and working with sheet metal to create various products and structures. Here are some common sheet metal tools:</p>
              <ul>
                <li><b>Tin Snips:</b> Tin snips, also known as aviation snips or compound snips, are used for cutting straight lines, curves, and complex shapes in sheet metal. They come in various designs for different cutting needs.</li>
                <li><b>Nibbler:</b> A nibbler is a tool that cuts small notches or patterns in sheet metal. It's useful for intricate cutting tasks and can be powered by hand or electrically.</li>
                <li><b>Shears:</b> Shears are designed for straight cuts in sheet metal. They are available in both manual and electric versions, with some capable of cutting thicker sheets.</li>
                <li><b>Bench Shear:</b> A bench shear is a stationary tool used for making long, straight cuts in sheet metal. It's mounted on a workbench for stability and precision.</li>
                <li><b>Brake Press:</b> A brake press or press brake is used to bend sheet metal into various angles and shapes. It's a vital tool for creating folds, seams, and edges.</li>
                <li><b>Roller:</b> A sheet metal roller, also known as a slip roller or plate roller, is used to curve or roll sheet metal into cylindrical or conical shapes.</li>
                <li><b>Hemming Tool:</b> Hemming tools are used to create hems or folded edges along the edges of sheet metal for safety and rigidity.</li>
                <li><b>Swaging Tool:</b> Swaging tools are used to reduce or increase the diameter of cylindrical metal tubing or create flared ends for connecting pipes or fittings.</li>
                <li><b>Soldering Iron:</b> Soldering irons are used to join sheet metal pieces together by melting a filler metal (solder) to create a strong bond.</li>
                <li><b>Duct Seamer:</b> Duct seamers are used in HVAC work to create a tight seam between two pieces of ductwork, ensuring a secure and airtight connection.</li>
                <li><b>Spot Welder:</b> Spot welders are used to join sheet metal pieces together by creating small, localized welds at specific points.</li>
                <li><b>Deburring Tool:</b> After cutting or shaping sheet metal, a deburring tool is used to remove sharp edges and burrs, ensuring a smooth and safe finish.</li>
                <li><b>Scribe:</b> A scribe is a pointed tool used for marking lines and measurements on sheet metal before cutting or bending.</li>
                <li><b>Dividers and Calipers:</b> These measuring tools help ensure accurate measurements and layouts when working with sheet metal.</li>
                <li><b>Marking and Layout Tools:</b> Various tools like rulers, squares, and protractors are essential for accurately marking and laying out patterns on sheet metal.</li>
                <li><b>File and Sandpaper:</b> Files and sandpaper are used for smoothing rough edges and refining the surface of sheet metal.</li>
                <li><b>Safety Gear:</b> When working with sheet metal, it's crucial to wear appropriate safety gear, including gloves, safety glasses, and hearing protection, to protect against sharp edges and flying debris.</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section className="inquiry">
    <div className="container">
      <div className="row">
        <div className="col-lg-12">
          <h3 className="text-uppercase">Get In Touch</h3>
          <p>Thank you for your interest in our company. If you have any questions or concerns about our products, please do not hesitate to contact us. We look forward to hearing from you soon!</p>
          <div className="m-t-30">
            <form method="post" id="form" name="form">
              <input name="vind" type="hidden" id="vind" defaultValue={53031} ifkey="vind" />
              <input name="ctype" type="hidden" id="ctype" defaultValue="I1172" ifkey="ctype" />
              <input name="pname" type="hidden" id="pname" defaultValue="Khyati Industries - Sheet Metal Tools" ifkey="pname" />
              <div className="row">
                <div className="form-group col-md-6">
                  <label htmlFor="name">Name</label>
                  <input type="text" id="name" name="name" className="form-control" placeholder="Name" />
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="email">Email</label>
                  <input type="text" id="mail" className="form-control" name="mail" placeholder="Email" />
                </div>
              </div>
              <div className="row">
                <div className="form-group col-md-6">
                  <label htmlFor="subject">Your Phone No</label>
                  <input type="text" id="subj" name="subj" placeholder="Phone" className="form-control" />
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="subject">Your Location</label>
                  <input type="text" id="location" name="location" placeholder="Location" className="form-control" />
                </div>
              </div>
              <div className="form-group">
                <label htmlFor="message">Message</label>
                <textarea id="message" name="message" className="form-control" placeholder="Enter Your Message" defaultValue={""} />
              </div>
              <button type="button" name="submit" onclick="PostData(this.form)" className="btn">SEND MESSAGE</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>




        </Layout>
    </>
  );
};

export default Sheetmeataltools;
