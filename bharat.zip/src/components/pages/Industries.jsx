import React from 'react'
import Layout from '../layout/Layout'
import "../pages/About.css";
import cert2 from '../../assets/img/cert-2.jpg'
import cert3 from '../../assets/img/cert-3.jpg'
import i1 from '../../assets/img/industries/appral.webp'
import i2 from '../../assets/img/industries/automobile.webp'
import i3 from '../../assets/img/industries/bearing.webp'
import i4 from '../../assets/img/industries/cementmanufacturing.webp'
import i5 from '../../assets/img/industries/cementplant.webp'
import i6 from '../../assets/img/industries/crane.webp'
import i7 from '../../assets/img/industries/digital.webp'
import i8 from '../../assets/img/industries/electrical.webp'
import i9 from '../../assets/img/industries/export.webp'
import i10 from '../../assets/img/industries/fiberglass.webp'
import i11 from '../../assets/img/industries/hardware-industry.webp'
import i12 from '../../assets/img/industries/hydraulic.webp'
import i13 from '../../assets/img/industries/pharma.webp'
import i14 from '../../assets/img/industries/printing.webp'
import i15 from '../../assets/img/industries/switchgear.webp'
import i16 from '../../assets/img/industries/textile.webp'
const Industries = () => {
  return (
   
    <>
    <Layout>
        {/* image coming from about.css */}
        <section className='hero-about'>
            <h1 style={{color:'White'}}>Industries We Serve</h1>
        </section>



     <section id="page-content">
  <div className="container">
    <div id="blog" className="grid-layout post-3-columns m-b-30 h2size" data-item="post-item" style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:'2rem 2rem', textAlign:'center'}}>
      <div className="post-item border">
        <div className="post-item-wrap">
          <div className="post-image">
            <img alt loading="lazy" src={i13} />
          </div>
          <div className="post-item-description">
            <h2 style={{fontSize:'20px'}}>Pharmaceutical Industry</h2>
          </div>
        </div>
      </div>
      <div className="post-item border">
        <div className="post-item-wrap">
          <div className="post-image">
            <img alt loading="lazy" src={i3} />
          </div>
          <div className="post-item-description">
            <h2 style={{fontSize:'20px'}}>Bearing Manufacturing Industry</h2>
          </div>
        </div>
      </div>
      <div className="post-item border">
        <div className="post-item-wrap">
          <div className="post-image">
            <img alt loading="lazy" src={i15} />
          </div>
          <div className="post-item-description">
            <h2 style={{fontSize:'20px'}}>Switch Gear Industry</h2>
          </div>
        </div>
      </div>
      <div className="post-item border">
        <div className="post-item-wrap">
          <div className="post-image">
            <img alt loading="lazy" src={i11} />
          </div>
          <div className="post-item-description">
            <h2 style={{fontSize:'20px'}}>Hardware Industries</h2>
          </div>
        </div>
      </div>
      <div className="post-item border">
        <div className="post-item-wrap">
          <div className="post-image">
            <img alt loading="lazy" src={i12} />
          </div>
          <div className="post-item-description">
            <h2 style={{fontSize:'20px'}}>Hydraulic System Industry</h2>
          </div>
        </div>
      </div>
      <div className="post-item border">
        <div className="post-item-wrap">
          <div className="post-image">
            <img alt loading="lazy" src={i7} />
          </div>
          <div className="post-item-description">
            <h2 style={{fontSize:'20px'}}>Digital Instruments Industry</h2>
          </div>
        </div>
      </div>
      <div className="post-item border">
        <div className="post-item-wrap">
          <div className="post-image">
            <img alt loading="lazy" src={i8} />
          </div>
          <div className="post-item-description">
            <h2 style={{fontSize:'20px'}}>Electrical Industry</h2>
          </div>
        </div>
      </div>
      <div className="post-item border">
        <div className="post-item-wrap">
          <div className="post-image">
            <img alt loading="lazy" src={i16} />
          </div>
          <div className="post-item-description">
            <h2 style={{fontSize:'20px'}}>Textile Industry</h2>
          </div>
        </div>
      </div>
      <div className="post-item border">
        <div className="post-item-wrap">
          <div className="post-image">
            <img alt loading="lazy" src={i2} />
          </div>
          <div className="post-item-description">
            <h2 style={{fontSize:'20px'}}>Automobile Industry</h2>
          </div>
        </div>
      </div>
      <div className="post-item border">
        <div className="post-item-wrap">
          <div className="post-image">
            <img alt loading="lazy" src={i6} />
          </div>
          <div className="post-item-description">
            <h2 style={{fontSize:'20px'}}>Crane Control Gear Industry</h2>
          </div>
        </div>
      </div>
      <div className="post-item border">
        <div className="post-item-wrap">
          <div className="post-image">
            <img alt loading="lazy" src={i14} />
          </div>
          <div className="post-item-description">
            <h2 style={{fontSize:'20px'}}>Printing Machinery Industry</h2>
          </div>
        </div>
      </div>
      <div className="post-item border">
        <div className="post-item-wrap">
          <div className="post-image">
            <img alt loading="lazy" src={i4} />
          </div>
          <div className="post-item-description">
            <h2 style={{fontSize:'20px'}}>Cement Machinery Industry</h2>
          </div>
        </div>
      </div>
      <div className="post-item border">
        <div className="post-item-wrap">
          <div className="post-image">
            <img alt loading="lazy" src={i5} />
          </div>
          <div className="post-item-description">
            <h2 style={{fontSize:'20px'}}>Cement Plant Industry</h2>
          </div>
        </div>
      </div>
      <div className="post-item border">
        <div className="post-item-wrap">
          <div className="post-image">
            <img alt loading="lazy" src={i1} />
          </div>
          <div className="post-item-description">
            <h2 style={{fontSize:'20px'}}>Apparel Park Industry</h2>
          </div>
        </div>
      </div>
      <div className="post-item border">
        <div className="post-item-wrap">
          <div className="post-image">
            <img alt loading="lazy" src={i10} />
          </div>
          <div className="post-item-description">
            <h2 style={{fontSize:'20px'}}>Fiber Glass Industry</h2>
          </div>
        </div>
      </div>
      <div className="post-item border">
        <div className="post-item-wrap">
          <div className="post-image">
            <img alt loading="lazy" src={i9} />
          </div>
          <div className="post-item-description">
            <h2 style={{fontSize:'20px'}}>Export</h2>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>



        </Layout>
    </>




  )
}

export default Industries