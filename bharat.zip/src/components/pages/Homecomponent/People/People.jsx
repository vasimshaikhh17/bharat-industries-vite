import React from "react";
import { comments, sliderSettings } from "../../../../utils/data";
import css from "./People.module.scss";
import Slider from "react-slick";
import {motion} from 'framer-motion'
import { footerVariants, staggerChildren, textVariant, textVariant2 } from "../../../../utils/motion";
import products from '../../../../assets/img/19.jpg/'
import procurement from '../../../../assets/img/products.png'
import Technicians from '../../../../assets/img/wide.png'
import MarketingRepresentative from '../../../../assets/img/thirdparty.png'
import ResearchandDevelopement from '../../../../assets/img/world.png'


const People = () => {
  return (
    <motion.section
    variants={staggerChildren}
    initial="hidden"
    whileInView="show"
    viewport={{ once: false, amount: 0.25 }}
    section className={`paddings ${css.wrapper}`}>

      <a className="anchor" id="people"></a>

      <motion.div
      variants={footerVariants}
      className={`yPaddings innerWidth ${css.container}`}>


        <div className={`flexCenter ${css.heading}`}>
          <span className="primaryText">Our Products</span>
          <p style={{ marginTop: "2rem", textAlign:"center" }}>
          Our company offers Sheet Metal Parts and Components as per customers specifications all dimension are controlled with perfect Sheet Metal dies and Sheet Metal tools.
          </p>
        </div>




        <div className={`yPaddings ${css.comments}`}>
          {/* to use slider , we have to inlcude css in index.html head */}
          <Slider {...sliderSettings} className={css.slider}>
            {comments.map((comment, i) => {
              return (
                <div className={`flexCenter ${css.comment}`}>
                  <img  src={comment.img} alt="" />
                  <p>{comment.name}</p>
                  <div className={css.post}></div>
                  <div className={css.post}>
                    {/* <span>{comment.name}</span>
                    <span>{comment.post}</span> */}
                  </div>
                </div>
              );
            })}
          </Slider>
        </div>


      </motion.div>

<section style={{paddingTop:'2rem'}}>
  <div className="container" >
    <div className="heading-text heading-section text-center">
      <h2 style={{color: '#000 !important'}}>Manufacturing Facility</h2>
      <span className="lead" style={{color: '#000 !important'}}>Acknowledging the pivotal role of teamwork in organizational success, we emphasize the significance of collaborative efforts within our ranks. With a steadfast commitment to fostering team synergy, we boast a dedicated workforce dedicated to maximizing customer
       satisfaction across all fronts. This cohesive team comprises the following individuals::</span>
    </div>
    <div className="row icon-boxes" style={{marginTop:'2rem', paddingTop:'5rem', boxShadow:' 1px 1px 36px #d5d5d5'}}>
      <div className="icon-boxx col-md-6 col-sm-4" >
        <div className="icon-box-content text-center">
          <img loading="lazy" src={procurement} alt="products" />
          <h3>Procurement Agents</h3>
          <p>Our representatives are dedicated to ensuring the procurement of optimal products, services, and resources at the most competitive rates..</p>
        </div>
      </div>
      <div className="icon-boxx col-md-6 col-sm-4" style={{padding:'0rem 2rem'}}>
        <div className="icon-box-content text-center">
          <img loading="lazy" src={Technicians} alt="Technicians" />
          <h3>Technicians </h3>
          <p>Our skilled engineers and technicians possess the expertise to fabricate machinery components utilizing state-of-the-art equipment. Moreover, we prioritize cultivating a conducive work environment for our team members.</p>
        </div>
      </div>
      <div className="icon-boxx col-md-6 col-sm-4" style={{padding:'5rem 2rem'}}>
        <div className="icon-box-content text-center">
          <img loading="lazy" src={MarketingRepresentative} alt="Marketing" />
          <h3>Marketing Representatives</h3>
          <p>Our organization benefits from a proficient team of marketing experts, tasked with conducting diverse market analysis activities. These include discerning market dynamics, customer inclinations, devising marketing strategies and budgets, and executing pertinent tasks crucial for bolstering sales performance.</p>
        </div>
      </div>
      <div className="icon-boxx col-md-6 col-sm-4" style={{padding:'5rem 2rem'}}>
        <div className="icon-box-content text-center">
          <img loading="lazy" src={ResearchandDevelopement} alt="Research & Development" />
          <h3>Research &amp; Development Experts </h3>
          <p>Within our organization, we are supported by a team of proficient R & D specialists. Their methodology involves gathering primary market data and soliciting customer feedback. Subsequently, these insights are amalgamated with the demands of various business tiers. Consequently, their endeavors facilitate innovation within our
             current product spectrum..</p>
        </div>
      </div>
      <div className="icon-boxx col-md-12 col-sm-12" style={{padding: '15px 40px', minHeight: 96}}>
        <div className="icon-box-content" style={{textAlign:'center'}}>
          <p>Our engineers and technicians are capable enough to develop machinery components by using latest machines. In addition to this, we ensure to provide the team members with a healthy work environment.</p>
        </div>
      </div>
    </div>
  </div>
</section>

    </motion.section>
  );
};

export default People;
