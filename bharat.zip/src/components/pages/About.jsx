import React from 'react'
import Layout from '../layout/Layout'
import "../pages/About.css";
import cert2 from '../../assets/img/cert-2.jpg'
import cert3 from '../../assets/img/cert-3.jpg'
const About = () => {
  return (
   
    <>
    <Layout>
        <section className='hero-about'>
            <h1 style={{color:'White'}}>About Us</h1>
        </section>

<section className='section-about'>
  <div className="container">
    <div className="row">
      <div className="col-md-12">
        <div className="heading-text heading-section">
          <h2>Bharat Industries</h2> <br />
        </div>
      </div>
      <div className="col-md-12">
        <p>Founded in the year 2015, SteelCraft Solutions emerged as a premier manufacturer and supplier specializing in an extensive array of Precision Forged and Metal Stamped Components. Our unwavering commitment has always been to deliver unparalleled quality to our clientele. Employing top-notch raw materials in our manufacturing process ensures that our products deliver optimal performance and functionality.</p>
        <p>Over the last two decades, our company has earned a sterling reputation among our clientele for providing top-notch, cost-effective solutions. Our products find extensive applications across both industrial and household sectors. Our diverse product portfolio encompasses Precision Machined Components, Metal Stamped Parts, Custom Tooling, Electrical Components, Brass Fittings, Copper Connectors, Stainless Steel Hardware, Mild Steel Components, and Deep Drawing Components..</p>
        <p>Our company, Spectrum Solutions, prides itself on delivering innovative solutions for even the most intricate components, leveraging advanced manufacturing techniques and cutting-edge technology. Our state-of-the-art production facility is equipped with the latest machinery to ensure precision and efficiency in every aspect of our operations. Continuously striving for excellence, we constantly integrate new production methodologies to provide our customers with an unparalleled selection of machinery parts. Moreover, we prioritize offering our product range at competitive prices and ensuring timely delivery to our valued customers.</p>
        <p>ur skilled workforce boasts extensive experience in this industry, coupled with an in-depth comprehension of market dynamics. They continuously motivate team members to collaborate effectively and actively contribute to the company's expansion.</p>
      </div>
    </div>
  </div>
</section>


{/* <section style={{background: '#e8e8e8', padding: '2rem'}}>
  <div className="container">
    <div className="heading-text heading-section text-center" style={{padding:'5rem'}}>
      <h4 style={{fontSize:'2rem'}}>Company Profile</h4>
      <hr />
    </div>
    <div className="row" style={{}}>
          <div className="col-lg-3 bgcol">
            <h4><i className="fa fa-building" /> Business Type</h4>
            <ul style={{marginLeft: 0}}>
              <li>Manufacturer</li>
            </ul>
          </div>
          <div className="col-lg-3 bgcol">
            <h4> <i className="fa fa-building" /> Year Of establishment</h4>
            <ul style={{marginLeft: 0}}>
              <li>2000</li>
            </ul>
          </div>
          <div className="col-lg-3 bgcol">
            <h4> <i className="fa fa-building" /> Legal Status of firm</h4>
            <ul style={{marginLeft: 0}}>
              <li>Proprietorship Firm</li>
            </ul>
          </div>
          <div className="col-lg-3 bgcol">
            <h4> <i className="fa fa-building" /> Major Markets</h4>
            <ul style={{marginLeft: 0}}>
              <li>USA</li>
              <li>East Asia</li>
              <li>South East Asia</li>
            </ul>
          </div>
          <div className="col-lg-3 bgcol">
            <h4> <i className="fa fa-building" /> Annual Turnover</h4>
            <ul style={{marginLeft: 0}}>
              <li>US$ 1-10 Million (or Rs. 4-40 Crore Approx)</li>
            </ul>
          </div>
          <div className="col-lg-3 bgcol">
            <h4> <i className="fa fa-building" /> Location Type</h4>
            <ul style={{marginLeft: 0}}>
              <li>Urban</li>
            </ul>
          </div>
          <div className="col-lg-3 bgcol">
            <h4> <i className="fa fa-building" /> Building Infrastructure</h4>
            <ul style={{marginLeft: 0}}>
              <li>Permanent</li>
            </ul>
          </div>
          <div className="col-lg-3 bgcol">
            <h4> <i className="fa fa-building" /> Size of Premises</h4>
            <ul style={{marginLeft: 0}}>
              <li>1,000 square feet</li>
            </ul>
          </div>
          <div className="col-lg-3 bgcol">
            <h4><i className="fa fa-building" /> Number of Employee</h4>
            <ul style={{marginLeft: 0}}>
              <li>25 to 40 People</li>
            </ul>
          </div>
          <div className="col-lg-3 bgcol">
            <h4><i className="fa fa-building" /> Banker</h4>
            <ul style={{marginLeft: 0}}>
              <li>Union bank of India</li>
            </ul>
          </div>

    </div>
  </div>
</section> */}




<section id="page-content">
  <div className="container">
    <div className="row">
      <div className="col-md-6">
        <div className="heading-text heading-section text-center">
          <h4>Our Vision</h4>
          <span className="lead">Striving for excellence in quality, affordability, timeliness, environmental stewardship, operational efficiency, and customer contentment on a global scale.</span>
        </div>
      </div>
      <div className="col-md-6">
        <div className="heading-text heading-section text-center">
          <h4>Why Choose Us?</h4>
          <span className="lead">The following factors have empowered us to maintain our competitive edge alongside industry peers:</span>
        </div>
      </div>
    </div>
  </div>
</section>


<section className="box-fancy section-fullwidth text-light p-b-40 " id="page-content">
  <div className="row">
    <div style={{backgroundColor: '#16A5DC', textAlign:'center', padding:'5rem 0rem'}} className="col-lg-4 quality">
      <h3>Quality range of
        <br />sheet metal components</h3>
    </div>
    <div style={{backgroundColor: '#2DAEDF', textAlign:'center', padding:'5rem 0rem'}} className="col-lg-4 quality">
      <h3>Sound <br /> Infrastructure</h3>
    </div>
    <div style={{backgroundColor: '#47B8E3', textAlign:'center', padding:'5rem 0rem'}} className="col-lg-4 quality">
      <h3>Qualified <br /> Team</h3>
    </div>
  </div>
  <div className="row p-t-10" id="market">
    <div className="col-lg-3">
    </div>
    <div style={{backgroundColor: '#61C2E7', textAlign:'center', padding:'5rem 0rem'}} className="col-lg-3 quality">
      <h3>Market<br /> Leading Prices</h3>
    </div>
    <div style={{backgroundColor: '#61c2e7d4', textAlign:'center', padding:'5rem 0rem'}} className="col-lg-3 quality">
      <h3>Timely <br />Delivery</h3>
    </div>
  </div>
</section>



<div>
  <section id="page-content" style={{background: '#e8e8e8'}}>
    <div className="container">
      <div className="heading-text heading-section text-center">
        <h4>Research &amp; Development</h4>
      </div>
      <div className="col-md-12 col-sm-12">
        <div className>
          <p>Within our company, we are supported by a dedicated team of seasoned R&D professionals. Their regular research endeavors enable the organization to acquire advanced technology and process insights. By gathering firsthand market intelligence and customer feedback, they synthesize these findings with the diverse operational needs of the business. Through this collaborative effort, we continually innovate and enhance our existing product range..</p>
        </div>
      </div>
    </div>
  </section>
  <section id="page-content">
    <div className="container">
      <div className="heading-text heading-section text-center">
        <h4>Client Satisfaction</h4>
      </div>
      <div className="col-md-12 col-sm-12">
        <div className>
          <p>In the realm of customer satisfaction, our organization stands out by consistently surpassing expectations, evident in the increasing volume of orders we receive daily. Our diligent customer research underscores the high level of satisfaction our products deliver. To uphold this position, we continuously innovate our machinery components, ensuring they remain at the forefront of quality and performance. Furthermore, we offer these parts at highly competitive prices, while also guaranteeing timely delivery as per our customers' specified timeframes. These efforts have propelled our organization to remarkable growth and reputation, establishing us as a leader in our field..</p>
        </div>
      </div>
    </div>
  </section>
  <section id="page-content" style={{background: '#e8e8e8'}}>
    <div className="container">
      <div className="heading-text heading-section text-center">
        <h4>Quality Assurance</h4>
      </div>
      <div className="col-md-12 col-sm-12">
        <div className>
          <h3 />
          <p>In our company, we prioritize the adherence of our machinery components to industry standards, ensuring their quality is consistently upheld. To achieve this, we rely on a team of seasoned quality controllers equipped with extensive industry experience. These professionals conduct rigorous inspections on our products to guarantee their integrity. Before final dispatch, our machinery components undergo meticulous testing on the following criteria:</p>
          <ul style={{display: 'flex', paddingLeft: 10, paddingTop: 10}}>
            <li style={{paddingRight: 55}}>Tensile strength</li>
            <li style={{paddingRight: 55}}>Corrosion resistance</li>
            <li>Wear &amp; tear resistance</li>
          </ul>
          <p>By taking all these parameters into consideration, we not only provide our customers with a flawless range but also gain their immense trust.</p>
        </div>
      </div>
    </div>
  </section>
</div>



<section className="box-fancy section-fullwidth text-light p-b-0 " id="page-content">
  <div className="container">
    <div className="heading-text heading-section text-center">
      <h2 style={{color: '#000', fontSize:'4rem'}}>Certification &amp; Membership</h2>
    </div>
    <div className="row" style={{marginTop:'10rem' , marginBottom:'5rem', paddingLeft:'7rem'}}>
      <div className="col-md-6" >
        <p style={{color: '#000'}}><strong>Certification Name :</strong> ISO Certification </p>
        <p style={{color: '#000'}}><strong>Certification Type: </strong>ISO 9001:2015 </p>
        <p style={{color: '#000'}}><strong>Start Date: </strong>12-September-2023</p>
      </div>
      <div className="col-md-6">
        <p style={{color: '#000'}}><strong>Expiry Date: </strong>11-September-2026</p>
        <p style={{color: '#000'}}><strong>Issued By: </strong> Absolute Quality Certification Pvt. Ltd (AQC)</p>
      </div>
    </div>
  </div>



  


{/* images of certificates box */}
  <div className="row" style={{paddingTop:'2rem'}}>
    <div className="col-lg-6" style={{paddingLeft:'5rem'}}>
      <img loading="lazy" src={cert2} style={{height: '30rem', width:'30rem'}} />
    </div>
    <div className="col-lg-6" style={{paddingLeft:'5rem'}}>
      <img loading="lazy" src={cert3} style={{height: '30rem', width:'30rem'}} />
    </div>
  </div>
</section>



    </Layout>
    </>




  )
}

export default About