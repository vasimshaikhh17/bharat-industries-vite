import React from "react";
import Layout from "../layout/Layout";
import "../pages/About.css";
const Sheetmeataltools = () => {
  return (
    <>

      <Layout>


         {/* image coming from about.css */}
         <section className="hero-about">
          <h1>Stamped Metal Parts</h1>
        </section>

      <div>
  <section>
    <div className="container">
      <div className="row">
        <div className="col-lg-12">
          <div className="heading-text heading-section">
            <h2>Materials for Metal Stamping Parts</h2>
          </div>
        </div>
        <div className="col-lg-12">
          <div className="row">
            <div className="col-lg-12">
              <p>Our company offers components as per customers drawing specifications all dimension are controlled with perfect dies and tools. Quality is controlled by special inspection gauges, for their critical assembly needs. These components are manufactured by experienced engineers and skilled workers thus providing complete satisfaction to our clients. These sheet metal components are available at most competitive prices.</p>
            </div>
            <div className="col-lg-6">
              <ul className="list-style">
                <li><i className="fa fa-check" /> Small Metal Parts</li>
                <li> <i className="fa fa-check" />Deep Drawing Parts</li>
                <li> <i className="fa fa-check" />Rivet Parts</li>
                <li> <i className="fa fa-check" />Contact Pin</li>
              </ul>
            </div>
            <div className="col-lg-6">
              <div className="col-lg-6">
                <ul className="list-style">
                  <li><i className="fa fa-check" />Contact Clips</li>
                  <li> <i className="fa fa-check" />Spring Clips</li>
                  <li> <i className="fa fa-check" />Shielding Case</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div></section>
  <section id="page-content">
    <div className="container">
      <div id="blog" className="grid-layout post-3-columns m-b-30" data-item="post-item">
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/1.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/2.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/3.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/4.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/5.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/6.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/7.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/8.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/9.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/10.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/11.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/12.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/13.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/14.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/15.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/16.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/17.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/18.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/19.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/20.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/21.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/22.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/23.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/24.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/25.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/26.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/27.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/28.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/29.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/30.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/31.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/32.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/33.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/34.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/35.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/36.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/37.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/38.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/39.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/40.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/41.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="index.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="index.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="index.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/45.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/46.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/47.html" />
              </a>
            </div> 
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/48.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/49.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/50.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/51.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/52.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/53.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/54.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/55.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/56.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/57.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/58.html" />
              </a>
            </div>
          </div>
        </div>
        <div className="post-item border">
          <div className="post-item-wrap">
            <div className="post-image">
              <a href="#">
                <img loading="lazy" alt src="img/ourproducts/59.html" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

        </Layout>
    </>
  );
};

export default Sheetmeataltools;