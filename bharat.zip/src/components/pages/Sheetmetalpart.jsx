import React from 'react'
import Layout from '../layout/Layout'

const Ourproducts = () => {
  return (
    <>
      <Layout>
        {/* image coming from about.css */}
        <section className="hero-about">
          <h1 style={{color:'black'}}>Sheet metal parts</h1>
        </section>

        <section>
          <div className="container">
            <div className="row">
              <div className="col-lg-12">
                <div className="row">
                  <div
                    className="col-lg-12 descset"
                    style={{ marginBottom: 30 }}
                  >
                    <h2 style={{ fontSize: 34, textAlign: "center" }}>
                      Precision Sheet Metal Parts Manufacturer &amp; Supplier
                    </h2>
                    <p>
                      Precision Sheet Metal Parts refer to components made from
                      sheet metal using high-accuracy manufacturing processes.
                      These parts often require tight tolerances, intricate
                      designs, and meticulous attention to detail. They find
                      applications in industries such as aerospace, electronics,
                      medical devices, telecommunications, and more. Here are
                      some key points related to precision sheet metal parts:
                    </p>
                    <h3>Sheet Metal Parts Materials:</h3>
                    <p>
                      Precision sheet metal parts can be made from a variety of
                      materials, including stainless steel, aluminum, copper,
                      brass, and various alloys. The choice of material depends
                      on factors such as strength, corrosion resistance, and
                      conductivity. We are provide{" "}
                      <a href="brass-sheet-metal-parts.html">
                        Brass Sheet Metal Parts
                      </a>
                      ,{" "}
                      <a href="ss-sheet-metal-parts.html">
                        S S Sheet Metal Parts
                      </a>
                      ,{" "}
                      <a href="ms-sheet-metal-parts.html">
                        M S Sheet Metal Parts
                      </a>
                      , Deep Draw Parts and{" "}
                      <a href="copper-sheet-metal-parts.html">
                        Copper Sheet Metal Parts.
                      </a>
                    </p>
                    <ul>
                      <h3>Sheet Metal Work:</h3>
                      <li>
                        <b>Cutting:</b> Laser cutting, waterjet cutting, and CNC
                        punching are commonly used to precisely cut intricate
                        shapes from sheet metal.
                      </li>
                      <li>
                        <b>Bending:</b> Press brakes are used to bend the metal
                        into the desired shape, following precise angles and
                        dimensions.
                      </li>
                      <li>
                        <b>Forming:</b> Roll forming and deep drawing processes
                        shape the metal into three-dimensional components.
                      </li>
                      <li>
                        <b>Welding:</b> Welding techniques such as TIG (Tungsten
                        Inert Gas) and MIG (Metal Inert Gas) are used for
                        joining sheet metal parts.
                      </li>
                      <li>
                        <b>Finishing:</b> Processes like deburring, sanding, and
                        powder coating ensure the final product meets quality
                        and aesthetic standards.
                      </li>
                    </ul>
                    <h3>Sheet Metal Parts Applications:</h3>
                    <p>
                      Precision sheet metal parts are used in a wide range of
                      applications, including chassis and enclosures for
                      electronics, brackets, panels, aerospace components,
                      medical equipment housings, and more.
                    </p>
                    <h3>Sheet Metal Parts Quality Control:</h3>
                    <p>
                      Rigorous quality control measures, such as dimensional
                      inspection, surface finish assessment, and testing, ensure
                      that precision sheet metal parts meet specifications.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>



<section className="inquiry">
  <div className="container">
    <div className="row">
      <div className="col-lg-12">
        <h3 className="text-uppercase">Get In Touch</h3>
        <p>Thank you for your interest in our company. If you have any questions or concerns about our products, please do not hesitate to contact us. We look forward to hearing from you soon!</p>
        <div className="m-t-30">
          <form method="post" id="form" name="form">
            <input name="vind" type="hidden" id="vind" defaultValue={53031} ifkey="vind" />
            <input name="ctype" type="hidden" id="ctype" defaultValue="I1172" ifkey="ctype" />
            <input name="pname" type="hidden" id="pname" defaultValue="Khyati Industries - Sheet Metal Parts" ifkey="pname" />
            <div className="row">
              <div className="form-group col-md-6">
                <label htmlFor="name">Name</label>
                <input type="text" id="name" name="name" className="form-control" placeholder="Name" />
              </div>
              <div className="form-group col-md-6">
                <label htmlFor="email">Email</label>
                <input type="text" id="mail" className="form-control" name="mail" placeholder="Email" />
              </div>
            </div>
            <div className="row">
              <div className="form-group col-md-6">
                <label htmlFor="subject">Your Phone No</label>
                <input type="text" id="subj" name="subj" placeholder="Phone" className="form-control" />
              </div>
              <div className="form-group col-md-6">
                <label htmlFor="subject">Your Location</label>
                <input type="text" id="location" name="location" placeholder="Location" className="form-control" />
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="message">Message</label>
              <textarea id="message" name="message" className="form-control" placeholder="Enter Your Message" defaultValue={""} />
            </div>
            <button type="button" name="submit" onclick="PostData(this.form)" className="btn">SEND MESSAGE</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>

      </Layout>
    </>
  );
};

export default Ourproducts;
